define(function() {
    return [
        {"name": "a", "description" : "a product"},
        {"name": "b", "description" : "b product"}
    ]
});
