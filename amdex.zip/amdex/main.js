require.config({
    baseUrl: 'js',
    paths : {
        'text' : 'https://cdnjs.cloudflare.com/ajax/libs/require-text/2.0.12/text',
        'handlebars' : "https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.2.0/handlebars.amd"
      }
});

require(['text!product.html','data','handlebars'],function(templ, products, hb) {
    var template = hb.compile(templ);
    var compiled = template({"products":products});
    document.querySelector(".container").innerHTML = compiled
    console.log(template, products, compiled);
});